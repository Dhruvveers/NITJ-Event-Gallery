module.exports=[
    {
        "_id": "6544d1118a8dc94c5561d2a7",
        "eventName": "Technofest",
        "eventType": "Coding",
        "startDate": "03-11-2023",
        "endDate": "03-11-2023",
        "eventDetail": "xyz",
        "eventCoordinators": "zyx",
        "__v": 0
    },
    {
        "_id": "6544d2ff0579504ce763ee5a",
        "eventName": "pratibha",
        "eventType": "Coding",
        "startDate": "03-11-2023",
        "endDate": "03-11-2023",
        "eventDetail": "xyz",
        "eventCoordinators": "zyx",
        "__v": 0
    }
]