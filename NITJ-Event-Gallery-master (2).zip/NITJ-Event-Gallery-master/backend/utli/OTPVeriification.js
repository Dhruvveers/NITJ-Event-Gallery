const OtpGeneration = require('./OTPGeneration')
const OtpVerification = async (GeneratedOtp,OtpToVerify) => {
    
    return true
}
module.exports = OtpVerification